﻿Cartagen: A Framework for Dynamic Mapping (Client Edition)

Version 0.6.1
Released 07/29/09

Copyright and license information is located in LICENSE.txt.

Information specific to this release, including changes, known bugs,
and contributor credits are in NOTES.txt.

For up-to-date documentation on this version of Cartagen, visit 
<http://cartagen.org/permalink/client-docs>.

